 {{-- DATA DAERAH TUJUAN --}}
 <div class="row mt-1">
     <div class="col-lg-12">
         <strong style="font-size:12px;">DATA DAERAH TUJUAN</strong>
     </div>
 </div>
 <div class="row">
     <div class="col-lg-12">
         <table style="width: 100%;">
             <tr>
                 <td style="font-size: 11px;">
                     <small>1. Nomor Kartu Keluarga</small>
                 </td>
                 <td style="text-align: right; width: 590px">
                     <table style="width: 590px">
                         <tr>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                 <p ></p>
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
         <table style="width: 100%; margin-top:1px">
             <tr>
                 <td style="font-size: 11px;">
                     2. Nama Kepala Keluarga
                 </td>
                 <td style="width: 590px">
                     <table style="width: 100%; ">
                         <tr>
                             <td style="width: 590px">
                                 <table style="width: 590px">
                                     <tr>
                                         <td
                                             style="border: 1px solid black; padding-left:8px; padding-right:8px;  font-size: 11px; ">
                                             <p ></p>
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
         <table style="width: 100%; margin-top:1px">
             <tr>
                 <td style="font-size: 11px;">
                     <small>3. NIK Kepala Keluarga</small>
                 </td>
                 <td style="text-align: right; width: 590px">
                     <table style="width: 590px">
                         <tr>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                 <p ></p>
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                             <td style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
         <table style="width: 100%;  margin-top:1px">
             <tr>
                 <td style="font-size: 11px;">
                     <small>4. Status Nomor KK Bagi Yang Pindah</small>
                 </td>
                 <td style="text-align: right; width: 590px">
                     <table>
                         <tr>
                             <td
                                 style="vertical-align: middle; border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                 <p ></p>
                             </td>
                             <td style="padding-left: 20px;">
                                 <table>
                                     <tr>
                                         <td style="font-size: 11px;">1. </td>
                                         <td class="text-start" style="font-size: 11px;"> Numpang KK</td>
                                     </tr>
                                 </table>
                             </td>
                             <td style="padding-left: 20px;">
                                 <table>
                                     <tr>
                                         <td style="font-size: 11px;">2. </td>
                                         <td class="text-start" style="font-size: 11px;"> Membuat KK Baru
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                             <td style="padding-left: 20px;">
                                 <table>
                                     <tr>
                                         <td style="font-size: 11px;">3. </td>
                                         <td class="text-start" style="font-size: 11px;"> Nama Kep. Keluarga
                                             dan Nomor KK Tetap</td>
                                     </tr>
                                 </table>
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
         <table style="width: 100%;  margin-top:1px">
             <tr>
                 <td style="font-size: 11px;">
                     <small>5. Tanggal Kedatangan</small>
                 </td>
                 <td style="text-align: right; width: 590px">
                     <table>
                         <tr>
                             <td style="padding-right: 25px">
                                 <table>
                                     <tr>
                                         <td
                                             style="border: 1px solid black; padding-left:20px; padding-right:20px; font-size: 11px;">
                                             <p ></p>
                                         </td>
                                         <td
                                             style="border: 1px solid black; padding-left:20px; padding-right:20px; font-size: 11px;">
                                             <p ></p>
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                             <td style="padding-right: 25px">
                                 <table>
                                     <tr>
                                         <td
                                             style="border: 1px solid black; padding-left:20px; padding-right:20px; font-size: 11px;">
                                             <p ></p>
                                         </td>
                                         <td
                                             style="border: 1px solid black; padding-left:20px; padding-right:20px; font-size: 11px;">
                                             <p ></p>
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                             <td style="padding-right: 25px">
                                 <table>
                                     <tr>

                                         <td
                                             style="border: 1px solid black; padding-left:20px; padding-right:20px; font-size: 11px;">
                                             <p ></p>
                                         </td>
                                         <td
                                             style="border: 1px solid black; padding-left:20px; padding-right:20px; font-size: 11px;">
                                             <p ></p>
                                         </td>
                                         <td
                                             style="border: 1px solid black; padding-left:20px; padding-right:20px; font-size: 11px;">
                                             <p ></p>
                                         </td>
                                         <td
                                             style="border: 1px solid black; padding-left:20px; padding-right:20px; font-size: 11px;">
                                             <p ></p>
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
         <table style="width: 100%; margin-top:1px">
             <tr>
                 <td style="font-size: 11px;">
                     6. Alamat Tujuan Pindah
                 </td>
                 <td style="width: 590px">
                     <table style="width: 590px">
                         <tr>
                             <td
                                 style="width: 500px; border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                 <p ></p>
                             </td>
                             <td>
                                 <table>
                                     <tr>
                                         <td style="padding-left:5px; padding-right:5px; font-size: 11px;">
                                             RT
                                         </td>
                                         <td>
                                             <table>
                                                 <tr>
                                                     <td
                                                         style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                         <p ></p>
                                                     </td>
                                                     <td
                                                         style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                         <p ></p>
                                                     </td>
                                                     <td
                                                         style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                         <p ></p>
                                                     </td>
                                                 </tr>
                                             </table>
                                         </td>
                                         <td style="padding-left:5px; padding-right:5px; font-size: 11px;">
                                             RW
                                         </td>
                                         <td>
                                             <table>
                                                 <tr>
                                                     <td
                                                         style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                         <p ></p>
                                                     </td>
                                                     <td
                                                         style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                         <p ></p>
                                                     </td>
                                                     <td
                                                         style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                         <p ></p>
                                                     </td>
                                                 </tr>
                                             </table>
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
         <table style="width: 100%; margin-top:1px">
             <tr>
                 <td style="padding-left: 15px; font-size: 11px;">
                     a. Desa/Kelurahan
                 </td>
                 <td style="width: 590px">
                     <table style="width: 100%">
                         <tr>
                             <td
                                 style="width: 250px; border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                 <p></p>
                             </td>
                             <td>
                                 <table>
                                     <tr>
                                         <td style="padding-right: 15px; padding-left:15px; font-size: 11px;">
                                             c. Kab/Kota
                                         </td>
                                         <td>
                                             <table style="width: 100%">
                                                 <tr>
                                                     <td
                                                         style="width: 250px; border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                         <p></p>
                                                     </td>
                                                 </tr>
                                             </table>
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
         <table style="width: 100%; margin-top:1px">
             <tr>
                 <td style="padding-left: 15px; font-size: 11px;">
                     b. Kecamatan
                 </td>
                 <td style="width: 590px">
                     <table style="width: 590px">
                         <tr>
                             <td
                                 style="width: 250px; border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                 <p></p>
                             </td>
                             <td>
                                 <table>
                                     <tr>
                                         <td style="padding-left: 15px; padding-right:21px; font-size: 11px;">
                                             d. Provinsi
                                         </td>
                                         <td>
                                             <table>
                                                 <tr>
                                                     <td style="width: 250px; border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                         <p></p>
                                                     </td>
                                                 </tr>
                                             </table>
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
         <table style="width: 100%; margin-top:1px;">
             <tr>
                 <td style="width:19%"></td>
                 <td>
                     <table>
                         <tr>
                             <td style="width:100%; font-size: 11px;">
                                 <table>
                                     <tr>
                                         <td style="width: 49%;  font-size: 11px;">Kode Pos</td>
                                         <td style="width: 40%;">
                                             <table>
                                                 <tr>
                                                     <td
                                                         style="border: 1px solid black; padding-left:5px; padding-right:5px; font-size: 11px;">
                                                         <p style="padding-top: 1px;padding-bottom: 1px; padding-left:5px; padding-right:5px;">
                                                         </p>
                                                     </td>
                                                     <td
                                                         style="border: 1px solid black; padding-left:5px; padding-right:5px; font-size: 11px;">
                                                         <p style="padding-top: 1px;padding-bottom: 1px; padding-left:5px; padding-right:5px;">
                                                         </p>
                                                     </td>
                                                     <td
                                                         style="border: 1px solid black; padding-left:5px; padding-right:5px; font-size: 11px;">
                                                         <p style="padding-top: 1px;padding-bottom: 1px; padding-left:5px; padding-right:5px;">
                                                         </p>
                                                     </td>
                                                     <td
                                                         style="border: 1px solid black; padding-left:5px; padding-right:5px; font-size: 11px;">
                                                         <p style="padding-top: 1px;padding-bottom: 1px; padding-left:5px; padding-right:5px;">
                                                         </p>
                                                     </td>
                                                     <td
                                                         style="border: 1px solid black; padding-left:5px; padding-right:5px; font-size: 11px;">
                                                         <p style="padding-top: 1px;padding-bottom: 1px; padding-left:5px; padding-right:5px;">
                                                         </p>
                                                     </td>
                                                 </tr>
                                             </table>
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                             <td>
                                 <table style="width: 250px;">
                                     <tr>
                                         <td style="padding-right:25px; font-size: 11px;">
                                             Telepon
                                         </td>
                                         <td style="width: 100%;">
                                             <table>
                                                 <tr>
                                                     <td>
                                                         <table>
                                                             <tr>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:1px; padding-right:1px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:1px; padding-right:1px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:1px; padding-right:1px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:1px; padding-right:1px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">

                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:1px; padding-right:1px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:1px; padding-right:1px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:1px; padding-right:1px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:1px; padding-right:1px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:5px; padding-right:5px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:5px; padding-right:5px;">
                                                                     </p>
                                                                 </td>
                                                                 <td
                                                                     style="border: 1px solid black; padding-left:8px; padding-right:8px; font-size: 11px;">
                                                                     <p
                                                                         style="padding-top: 1px;padding-bottom: 1px; padding-left:5px; padding-right:5px;">
                                                                     </p>
                                                                 </td>
                                                             </tr>
                                                         </table>
                                                     </td>
                                                 </tr>
                                             </table>
                                         </td>
                                     </tr>
                                 </table>
                             </td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
         <table style="width: 100%;  margin-top:1px">
             <tr>
                 <td style="font-size: 11px;">
                     <small>7. Keluarga Yang Datang</small>
                 </td>
                 <td style="text-align: right; width: 590px">
                 </td>
             </tr>
         </table>
     </div>
     <div class="col-lg-12" style="width: 100%;  margin-top:1px">
         <table style="width:100%; text-align: center;">
             <thead style="border: 1px solid black;">
                 <th style="border: 1px solid black; font-size: 11px; width:5%;">NO</th>
                 <th style="border: 1px solid black; font-size: 11px; width:45%;" colspan="16">NIK</th>
                 <th style="border: 1px solid black; font-size: 11px; width:35%;">NAMA</th>
                 <th style="border: 1px solid black; font-size: 11px; width:15%;" colspan="2">SDHK</th>
             </thead>
             <tbody style="border: 1px solid black">
                 <tr style="border: 1px solid black">
                     <td style="border: 1px solid black; font-size: 11px;"></td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding-left:8px; padding-right:8px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;"></td>
                     <td style="border: 1px solid black; font-size: 11px;"></td>
                 </tr>
                 <tr style="border: 1px solid black">
                     <td style="border: 1px solid black; font-size: 11px;"></td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding-left:8px; padding-right:8px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;"></td>
                     <td style="border: 1px solid black; font-size: 11px;"></td>
                 </tr>
                 <tr style="border: 1px solid black">
                     <td style="border: 1px solid black; font-size: 11px;"></td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding:1px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;">
                         <p style="padding-left:8px; padding-right:8px;"></p>
                     </td>
                     <td style="border: 1px solid black; font-size: 11px;"></td>
                     <td style="border: 1px solid black; font-size: 11px;"></td>
                 </tr>
             </tbody>
         </table>
     </div>
 </div>
 {{-- TTD FOOTER --}}
 <div class="row mt-1">
     <div class="col-lg-12">
         <table style="width: 100%; text-align:center;">
             <tr>
                 <td>
                     <table style="text-align: left; font-size:11px; width:50%;">
                         <tr>
                             <td>Diketahui Oleh: <br>Camat <br>No. .................., tgl............,20......</td>
                         </tr>
                         <tr>
                             <td style="padding-top: 50px"><u>(........................................)</u>
                                 <br>NIP.
                             </td>
                         </tr>
                     </table>
                 </td>

                 <td>
                     <table style="text-align: left; font-size:11px; width:50%;">
                         <tr>
                             <td>Diketahui Oleh: <br>Kepala Desa/Lurah <br>No. {{ $pendudukPindah->no_surat }}, Tanggal {{ Carbon\Carbon::parse($pendudukPindah->created_at)->isoFormat('D MMMM Y') }}
                             </td>
                         </tr>
                         <tr>
                             <td style="padding-top: 50px"><u><strong>RUSKANDA</strong></u></td>
                         </tr>
                     </table>
                 </td>
             </tr>
         </table>
     </div>
 </div>
