<script src="{{ asset('landings/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{ asset('landings/assets/libs/simplebar/dist/simplebar.min.js')}}"></script>
<script src="{{ asset('landings/assets/libs/headhesive/dist/headhesive.min.js')}}"></script>

<!-- Theme JS -->
{{-- <script src="{{ asset('landings/assets/js/vendor/theme.min.js')}}"></script> --}}

<script src="{{ asset('landings/assets/libs/jarallax/dist/jarallax.min.js')}}"></script>
<script src="{{ asset('landings/assets/js/vendors/jarallax.js')}}"></script>
<script src="{{ asset('landings/assets/libs/scrollcue/scrollCue.min.js')}}"></script>
<script src="{{ asset('landings/assets/js/vendors/scrollcue.js')}}"></script>
<script src="{{ asset('landings/assets/libs/swiper/swiper-bundle.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
