<?php $page="error-404";?>

<?php $__env->startSection('content'); ?>
    <div class="error-box">
        <h1>404</h1>
        <h3><i class="fa fa-warning"></i> Oops! Halaman yang anda cari tidak ada!</h3>
        <br><br>
        <a href="<?php echo e(route('lp.root')); ?>" class="btn btn-custom">Kembali Ke Halaman Utama</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.errorlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/errors/404_FE.blade.php ENDPATH**/ ?>