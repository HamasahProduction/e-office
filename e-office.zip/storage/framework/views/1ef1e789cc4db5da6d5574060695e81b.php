
<div class="modal fade" id="import-penduduk" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-full-width">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Import Penduduk</h5>
                
            </div>
            <form action="<?php echo e(route('app.admin.penduduk.import')); ?>" method="POST" enctype="multipart/form-data" id="importForm">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-lg-12 col-form-label">Silahkan Import File<span class="text-danger">*</span></label>
                        <div class="col-lg-12">
                            <input type="file" name="file" required class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('file')); ?>">
                            <div class="invalid-feedback">
                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="closeBtn" type="button" class="btn btn-light btn-import-close" data-bs-dismiss="modal">Close</button>
                    <button id="uploadBtn" type="submit" class="btn btn-primary btn-import">Upload</button>
                    <button id="loadingBtn" class="btn btn-primary btn-import-spiner" style="display: none;" type="button" disabled="">
                        <span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>
                        Loading...
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/admin/penduduk/modal/import_penduduk.blade.php ENDPATH**/ ?>