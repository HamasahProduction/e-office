<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.breadcrumb'); ?>
        <?php $__env->slot('title'); ?>
            Data Buku Induk Penduduk
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('li_1'); ?>
            Data Buku Induk Penduduk
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('li_2'); ?>
            Daftar
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="" method="get">
                        <div class="row filter-row">

                            <div class="col-md-2">
                                <div class="form-group form-focus select-focus focused">
                                    <input type="date" class="form-control" name="birthday"
                                        value="<?php echo e(old('birthday', request('birthday', $birthday))); ?>">
                                    <label class="focus-label">Tanggal Lahir </label>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group form-group form-focus select-focus focused">
                                    <select class="select2 col-lg-12" name="status" id="status">
                                        <option selected disabled>Status Penduduk</option>
                                        <option value="">--Semua Status--</option>
                                        <option value="tetap" <?php echo e(request('status') == 'tetap' ? 'selected' : ''); ?>>
                                            Penduduk Tetap</option>
                                        <option value="tidak_tetap"
                                            <?php echo e(request('status') == 'tidak_tetap' ? 'selected' : ''); ?>>
                                            Tidak Tetap</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group form-group form-focus select-focus focused">
                                    <select class="select2 col-lg-12" name="rt_id" id="rt_id">
                                        <option selected disabled>Pilih RT</option>
                                        <?php $__currentLoopData = $rts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>">RT : <?php echo e($item->nomor); ?> | RW :
                                                <?php echo e($item->rw); ?> | <?php echo e($item->dusun); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4 col-12">
                                <div class="col-md-8 float-start">
                                    <button type="submit"
                                        onclick="javascript: form.action='<?php echo e(route('app.admin.penduduk.index')); ?>';"
                                        class="btn btn-primary w-20 btn-sm ">Filter Data
                                    </button>
                                    <button type="submit" target="_blank"
                                        onclick="javascript: form.action='<?php echo e(route('app.admin.penduduk.index')); ?>';"
                                        class="btn btn-warning w-20 btn-sm">Refresh</button>
                                </div>
                            </div>
                        </div>
                    </form>

                    <div class="tab-content">
                        <div class="tab-pane show active">
                            <div class="table-responsive">
                                <table class="table table-striped custom-table no-footer mb-0 datatable">
                                    <thead>
                                        <tr>
                                            <th>Dusun/RT/RW</th>
                                            <th>Nama</th>
                                            <th>NIK</th>
                                            <th>No KK</th>
                                            <th style="width: 10%">Orangtua</th>
                                            <th>Alamat</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($penduduk->Rt->dusun); ?> <br>RT: <?php echo e($penduduk->Rt->nomor); ?>

                                                    /RW: <?php echo e($penduduk->Rt->rw); ?></td>
                                                <td><strong><?php echo e($penduduk->nama_lengkap); ?></strong> <br> TGL Lahir :
                                                    <?php echo e(Carbon\Carbon::parse($penduduk->tgl_lahir)->isoFormat('dddd, D MMMM Y')); ?>

                                                </td>
                                                <td><?php echo e($penduduk->nik); ?></td>
                                                <td><?php echo e($penduduk->no_kk); ?></td>
                                                <td><strong>AYAH : <?php echo e($penduduk->nama_ayah ?? '-'); ?> <br> IBU :
                                                        <?php echo e($penduduk->nama_ibu ?? '-'); ?></strong></td>
                                                <td><?php echo wordwrap($penduduk->alamat, 50, "<br>\n"); ?></td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.select2').select2();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/admin/administrasi_penduduk/buku_induk/index.blade.php ENDPATH**/ ?>