







<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('assets/img/favicon.png')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/plugins/fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/line-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/material.css')); ?>">

<link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/plugins/fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/line-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/material.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/line-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">



<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.css" rel="stylesheet"
    type="text/css" />
<?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/layout/partials/head.blade.php ENDPATH**/ ?>