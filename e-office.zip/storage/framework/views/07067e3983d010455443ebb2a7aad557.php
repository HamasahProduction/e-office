<div class="offcanvas-body pt-0 align-items-left">
    <ul class="navbar-nav mx-auto align-items-lg-left">
        <li class="nav-item dropdown">
            <a class="nav-link text-black" href="<?php echo e(route('lp.root')); ?>">Home</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="<?php echo e(route('lp.about')); ?>">About</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="<?php echo e(route('lp.dokumentasi')); ?>">Dokumentasi</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="<?php echo e(route('lp.landing-page.artikel.index')); ?>">Lembaga</a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="<?php echo e(route('lp.landing-page.artikel.index')); ?>">Artikel</a>
        </li>
        <?php if(auth()->guard()->check()): ?>
        <li class="nav-item dropdown">
            <a class="nav-link" href="<?php echo e(route('lp.layanan-umum.layanan')); ?>">Administrasi</a>
        </li>
        
            <li class="nav-item dropdown">
                <a class="nav-link" href="<?php echo e(route('lp.warga.warga.dashboard')); ?>">Dashboard</a>
            </li>
        <?php endif; ?>


    </ul>
    <div class="mt-3 mt-lg-0 d-flex align-items-center">
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('lp.logout')); ?>" class="btn btn-outline-primary">Logout</a>
        <?php else: ?>
            <a href="<?php echo e(route('login-client')); ?>" class="btn btn-primary mx-2">Login</a>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/landing-page/layout/partials/nav.blade.php ENDPATH**/ ?>