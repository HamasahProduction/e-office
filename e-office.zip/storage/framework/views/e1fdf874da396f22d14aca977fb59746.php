<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="page-header">
        <div class="row mb-5">
            <div class="col-sm-12">
                <h3 class="page-title">Selamat datang ...!</h3>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item active">Dashboard</li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-lg-6 col-xl-6 d-flex">
                <div class="card flex-fill">
                    <div class="card-body">
                        <h4 class="card-title">Kelembagaan</h4>
                        <div class="statistics">
                            <div class="row">
                                <div class="col-md-6 col-6 text-center">
                                    <div class="stats-box mb-4">
                                        <p>Aktif</p>
                                        <h3></h3>
                                    </div>
                                </div>
                                <div class="col-md-6 col-6 text-center">
                                    <div class="stats-box mb-4">
                                        <p>Tidak Aktif</p>
                                        <h3></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <?php $__currentLoopData = $lembagas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lembaga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><i
                                        class="fa-regular fa-circle-dot <?php echo e($lembaga->is_active == true ? 'text-success' : 'text-danger'); ?> me-2"></i><?php echo e($lembaga->nama_lembaga); ?><span
                                        class="float-end"><?php echo e($lembaga->is_active == true ? 'Aktif' : 'Tidak Aktif'); ?></span></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-lg-6 col-xl-6 d-flex">
                <div class="card flex-fill">
                    <div class="card-body">
                        <h4 class="card-title">Jumlah Penduduk <span
                                class="badge bg-inverse-warning ms-6"><?php echo e($pendudukCount); ?></span></h4>
                        <div class="leave-info-box">
                            <div class="media d-flex align-items-center">
                                <a href="profile.html" class="avatar"><img src="assets/img/user.jpg" alt="User Image"></a>
                                <div class="media-body flex-grow-1">
                                    <div class="text-sm my-0">Penduduk Laki-Laki</div>
                                </div>
                            </div>
                            <div class="row align-items-center mt-3">
                                <div class="col-12">
                                    <h4 class="mb-0">Jumlah : <?php echo e($pendudukPria); ?></h4>
                                </div>
                            </div>
                        </div>
                        <div class="leave-info-box">
                            <div class="media d-flex align-items-center">
                                <a href="profile.html" class="avatar"><img src="assets/img/user.jpg" alt="User Image"></a>
                                <div class="media-body flex-grow-1">
                                    <div class="text-sm my-0">Penduduk Perempuan</div>
                                </div>
                            </div>
                            <div class="row align-items-center mt-3">
                                <div class="col-12">
                                    <h4 class="mb-0">Jumlah : <?php echo e($pendudukWanita); ?></h4>
                                </div>
                            </div>
                        </div>
                        <div class="leave-info-box">
                            <div class="media d-flex align-items-center">
                                <a href="profile.html" class="avatar"><img src="assets/img/user.jpg" alt="User Image"></a>
                                <div class="media-body flex-grow-1">
                                    <div class="text-sm my-0">Kepala Keluarga</div>
                                </div>
                            </div>
                            <div class="row align-items-center mt-3">
                                <div class="col-12">
                                    <h4 class="mb-0">Jumlah : <?php echo e($kepalaKeluarga); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 d-flex">
                <div class="card card-table flex-fill">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Permohonan Surat</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table custom-table mb-0">
                                <thead>
                                    <tr>
                                        <th>Nama Permohonan </th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $permohonanAdministrasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <h2><a
                                                        href="project-view.html"><strong><?php echo e($permohonan->jenis_surat); ?></strong></a>
                                                </h2>
                                                <small class="block text-ellipsis">
                                                    <span>NIK</span> <span class="text-muted"><?php echo e($permohonan->nik); ?>,
                                                    </span>
                                                    <span>Pemohon</span> <span
                                                        class="text-muted"><?php echo e($permohonan->nama_pemohon); ?></span>
                                                </small>
                                            </td>
                                            <td>
                                                <span class="badge badge-warning"><?php echo e($permohonan->status); ?></span>
                                            </td>
                                            <td>
                                                <?php echo e($permohonan->tgl_permohonan); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('app.admin.permohonan_surat.index')); ?>">Lihat Semua</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 d-flex">
                <div class="card card-table flex-fill">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Aktivitas Surat</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-nowrap custom-table mb-0">
                                <thead>
                                    <tr>
                                        <th>Tgl Surat Masuk</th>
                                        <th>Tanggal Surat</th>
                                        <th>Nama Instansi</th>
                                        <th>Nomor Surat</th>
                                        <th>Perihal</th>
                                        <th>Isi Surat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $suratMasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(Carbon\Carbon::parse($surat->tgl_surat_masuk)->isoFormat('D MMMM Y')); ?>

                                        <td><?php echo e(Carbon\Carbon::parse($surat->tgl_surat)->isoFormat('D MMMM Y')); ?>

                                        <td><?php echo e($surat->nama_instansi_pengirim); ?></td>
                                        <td><?php echo e($surat->nomor_surat); ?></td>
                                        <td><?php echo e($surat->perihal); ?></td>
                                        <td><?php echo wordwrap($surat->deskripsi_surat, 20, "<br>\n"); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('app.admin.surat-masuk.index')); ?>">Lihat Semua</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>