<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.breadcrumb'); ?>
        <?php $__env->slot('title'); ?>
            Penduduk Pindah
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('li_1'); ?>
            Penduduk Pindah
        <?php $__env->endSlot(); ?>
        <?php $__env->slot('li_2'); ?>
            Form F-1.08
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
    <?php if(session('errorSimpan')): ?>
        <?php $errorSimpan = session('errorSimpan'); ?>
        <?php if(count($errorSimpan) > 0): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php $__currentLoopData = $errorSimpan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5> <?php echo $error; ?></h5>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <form action="<?php echo e(route('app.admin.surat-keterangan-pindah-datang.store')); ?>" method="post"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group row">
                                    <div class="col-lg-12">
                                        <small class="text-muted">DATA DAERAH ASAL :</small>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Jenis Kepindahan <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="jenis_kepindahan_id" id="jenis_kepindahan_id"
                                            class="select2 form-control <?php $__errorArgs = ['jenis_kepindahan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('jenis_kepindahan_id')); ?>">
                                            <option selected disabled>--Pilih Jenis Kepindahan--</option>
                                            <?php $__currentLoopData = $JenisPindah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($jenis->id); ?>"><?php echo e($jenis->keterangan); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['jenis_kepindahan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Kepala Keluarga <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="kk_id" id="kk_id"
                                            class="select2 form-control <?php $__errorArgs = ['kk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('kk_id')); ?>">
                                            <option selected disabled>--Pilih Kepala Keluarga--</option>
                                            <?php $__currentLoopData = $kepalaKeluarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($kk->id); ?>">NIK: <?php echo e($kk->nik); ?> |
                                                    <?php echo e($kk->penduduk->nama_lengkap); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['kk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Pemohon <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="nik_pemohon" id="pemohon"
                                            class="multipleSelect form-control select2 <?php $__errorArgs = ['nik_pemohon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('nik_pemohon')); ?>" disabled>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['nik_pemohon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row" id="showPenduduk">
                                    <label class="col-lg-3 col-form-label">Anggota Keluarga <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="anggota_keluarga[]" id="anggota_keluarga" multiple="multiple"
                                            class="multipleSelect form-control select2 col-lg-12 <?php $__errorArgs = ['anggota_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('anggota_keluarga')); ?>" disabled>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['anggota_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Tanggal Pindah<span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input type="date" name="rencana_tgl_pindah" maxlength="255" minlength="5" 
                                            class="form-control <?php $__errorArgs = ['rencana_tgl_pindah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('rencana_tgl_pindah')); ?>">
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['rencana_tgl_pindah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-7    ">
                                        <div class="form-group row">
                                            <label class="col-lg-5 col-form-label">Telpon / No HP<span
                                                    class="text-danger">*</span></label>
                                            <div class="col-lg-7">
                                                <input type="text" name="no_hp" maxlength="13" minlength="5"
                                                    class="form-control <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    value="<?php echo e(old('no_hp')); ?>">
                                                <div class="invalid-feedback">
                                                    <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-5">
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label">Kode Pos<span
                                                    class="text-danger">*</span></label>
                                            <div class="col-lg-8">
                                                <input type="text" name="kode_pos_asal" maxlength="5" minlength="5"
                                                    class="form-control <?php $__errorArgs = ['kode_pos_asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    value="<?php echo e(old('kode_pos_asal')); ?>">
                                                <div class="invalid-feedback">
                                                    <?php $__errorArgs = ['kode_pos_asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-lg-12">
                                        <small class="text-muted">DATA KEPINDAHAN :</small>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Klasifikasi Pindah <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="klasifikasi_pindah_id" id="klasifikasi_pindah_id"
                                            class="select2 form-control <?php $__errorArgs = ['klasifikasi_pindah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('klasifikasi_pindah_id')); ?>">
                                            <option selected disabled>--Pilih Klasifikasi Pindah--</option>
                                            <?php $__currentLoopData = $KlasifikasiPindah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $klasifikasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($klasifikasi->id); ?>"><?php echo e($klasifikasi->keterangan); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['klasifikasi_pindah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Alasan Pindah <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="alasan_pindah_id" id="alasan_pindah_id"
                                            class="select2 form-control <?php $__errorArgs = ['alasan_pindah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('alasan_pindah_id')); ?>">
                                            <option selected disabled>--Pilih Alasan Pindah--</option>
                                            <?php $__currentLoopData = $AlasanPindah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($alasan->id); ?>"><?php echo e($alasan->keterangan); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['alasan_pindah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Status KK Tidak Pindah <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="status_kk_tdk_pindah_id" id="status_kk_tdk_pindah_id"
                                            class="select2 form-control <?php $__errorArgs = ['status_kk_tdk_pindah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('status_kk_tdk_pindah_id')); ?>">
                                            <option selected disabled>--Pilih Status KK Tidak Pindah--</option>
                                            <?php $__currentLoopData = $StatusKKTidakPindah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statuskk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($statuskk->id); ?>"><?php echo e($statuskk->keterangan); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['status_kk_tdk_pindah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Status KK Yang Pindah <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="status_kk_pindah_id" id="status_kk_pindah_id"
                                            class="select2 form-control <?php $__errorArgs = ['status_kk_pindah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('status_kk_pindah_id')); ?>">
                                            <option selected disabled>--Pilih Status KK Yang Pindah--</option>
                                            <?php $__currentLoopData = $StatusKKYangPindah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statuskk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($statuskk->id); ?>"><?php echo e($statuskk->keterangan); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['status_kk_pindah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row">
                                    <div class="col-lg-12">
                                        <small class="text-muted">SILAHKAN PILIH ALAMAT TUJUAN PINDAH :</small>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Dusun Tujuan<span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input type="text" name="dusun_tujuan" maxlength="255" minlength="5"
                                            placeholder="Contoh: DUSUN CIMARA"
                                            class="form-control <?php $__errorArgs = ['dusun_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('dusun_tujuan')); ?>">
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['dusun_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label class="col-lg-6 col-form-label">RT Tujuan<span
                                                    class="text-danger">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" name="rt_tujuan" maxlength="3" minlength="2"
                                                    placeholder="Contoh: 001"
                                                    class="form-control <?php $__errorArgs = ['rt_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    value="<?php echo e(old('rt_tujuan')); ?>">
                                                <div class="invalid-feedback">
                                                    <?php $__errorArgs = ['rt_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group row">
                                            <label class="col-lg-5 col-form-label">RW Tujuan<span
                                                    class="text-danger">*</span></label>
                                            <div class="col-lg-7">
                                                <input type="text" name="rw_tujuan" maxlength="3" minlength="2"
                                                    placeholder="Contoh: 001"
                                                    class="form-control <?php $__errorArgs = ['rw_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    value="<?php echo e(old('rw_tujuan')); ?>">
                                                <div class="invalid-feedback">
                                                    <?php $__errorArgs = ['rw_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Kode Pos Tujuan<span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input type="text" name="kode_pos_tujuan" maxlength="5" minlength="5"
                                            class="form-control <?php $__errorArgs = ['kode_pos_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('kode_pos_tujuan')); ?>">
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['kode_pos_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Provinsi <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="provinsi_tujuan" id="provinsi_tujuan"
                                            class="select2 province form-control <?php $__errorArgs = ['provinsi_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('provinsi_tujuan')); ?>">
                                            <option value="" selected>== Pilih Provinsi ==</option>
                                            <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['provinsi_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Kab. / Kota <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select
                                            class="select2 regency form-control <?php $__errorArgs = ['kabupaten_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="kabupaten_tujuan" id="kabupaten_tujuan"
                                            value="<?php echo e(old('kabupaten_tujuan')); ?>">
                                            <option value="" selected>== Pilih Kab. / Kota ==</option>

                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['kabupaten_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Kecamatan <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="kecamatan_tujuan" id="kecamatan_tujuan"
                                            class="select2 district form-control <?php $__errorArgs = ['kecamatan_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('kecamatan_tujuan')); ?>">
                                            <option value="" selected>== Pilih Kecamatan ==</option>

                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['kecamatan_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label">Desa / Kelurahan <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select name="desa_tujuan" id="desa_tujuan"
                                            class="select2 village form-control <?php $__errorArgs = ['desa_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('desa_tujuan')); ?>">
                                            <option value="" selected>== Pilih Desa / Kelurahan ==</option>

                                        </select>
                                        <div class="invalid-feedback">
                                            <?php $__errorArgs = ['desa_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="card-footer text-end">
                        <span class="text-muted float-start">
                            <strong class="text-danger">*</strong> Harus diisi
                        </span>
                        <a class="btn btn-secondary"
                            href="<?php echo e(route('app.admin.surat-keterangan-pindah-datang.index')); ?>">Kembali</a>
                        <button class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.multipleSelect').select2();
            $('.select2').select2();
        });
        $(document).ready(function() {
            $('#showPenduduk').prop('disabled', true);
            $('#jenis_kepindahan_id').change(function() {
                var jenis_kepindahan = $(this).val();
                if (jenis_kepindahan == 3 || jenis_kepindahan == 4) {
                    $('#showPenduduk').prop('disabled', false);

                } else {
                    $('#showPenduduk').prop('disabled', true);
                }
            });

            $('#kk_id').change(function() {
                var kkId = $(this).val();
                if (kkId) {
                    $.ajax({
                        url: '<?php echo e(route('app.admin.surat-keterangan-pindah-datang.anggota-keluarga')); ?>',
                        type: 'GET',
                        data: {
                            kk_id: kkId
                        },
                        success: function(data) {
                            var jp = $('#jenis_kepindahan_id').val();

                            $('#pemohon').empty();
                            if (data.length > 0) {
                                $.each(data, function(key, value) {
                                    $('#pemohon').append('<option value="' +
                                        value.id + '">' + value.s_d_h_k.keterangan +
                                        ' | ' + value.nik + ' | ' + value
                                        .penduduk.nama_lengkap + '</option>');
                                });
                                $('#pemohon').prop('disabled', false);

                            } else {
                                $('#pemohon').append(
                                    '<option value="">--Tidak Ada Anggota Keluarga--</option>'
                                );
                                $('#pemohon').prop('disabled', true);
                            }
                            // console.info(jp);
                            if (jp == 3 || jp == 4) {
                                $('#anggota_keluarga').empty();
                                if (data.length > 0) {
                                    $.each(data, function(key, value) {
                                        $('#anggota_keluarga').append(
                                            '<option value="' +
                                            value.id + '">' + value.nik + ' | ' +
                                            value
                                            .penduduk.nama_lengkap + '</option>');
                                    });
                                    $('#anggota_keluarga').prop('disabled', false);

                                } else {
                                    $('#anggota_keluarga').append(
                                        '<option value="">--Tidak Ada Anggota Keluarga--</option>'
                                    );
                                    $('#anggota_keluarga').prop('disabled', true);
                                }
                            } else {
                                $('#anggota_keluarga').prop('disabled', true);
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error(error);
                        }
                    });
                } else {
                    $('#pemohon').empty();
                    $('#pemohon').prop('disabled', true);
                    $('#anggota_keluarga').empty();
                    $('#anggota_keluarga').prop('disabled', true);
                }
            });
        });

        $('#pemohon').change(function() {
            var idpemohon = $(this).val();
            console.info(idpemohon);
            $.ajax({
                url: '<?php echo e(route('app.admin.surat-keterangan-pindah-datang.alamat-pemohon')); ?>',
                type: 'GET',
                data: {
                    id: idpemohon
                },
                success: function(data) {
                    console.info(data);
                    $('#nama_dusun').val(data.rt.dusun);
                    $('#rt_asal').val(data.rt.nomor);
                    $('#rw_asal').val(data.rt.rw);
                    $('#provinsi_asal').val(data.province.name);
                    $('#kabupaten_asal').val(data.regency.name);
                    $('#kecamatan_asal').val(data.district.name);
                    $('#desa_asal').val(data.village.name);
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        });

        function onChangeSelect(url, id, name) {
            // send ajax request to get the cities of the selected province and append to the select tag
            console.log(id);
            $.ajax({
                url: url,
                type: 'GET',
                data: {
                    id: id
                },
                success: function(data) {
                    $('#' + name).empty();
                    $('#' + name).append('<option>==Pilih Salah Satu==</option>');

                    console.log(data);
                    $.each(data, function(key, value) {
                        $('#' + name).append('<option value="' + value.id + '">' + value.name +
                            '</option>');
                    });
                }
            });
        }
        $(function() {
            $('.select2').select2();
            $('#provinsi_tujuan').on('change', function() {
                onChangeSelect('<?php echo e(route('app.admin.surat-keterangan-pindah-datang.regency')); ?>', $(this)
                    .val(),
                    'kabupaten_tujuan');
            });
            $('#kabupaten_tujuan').on('change', function() {
                onChangeSelect('<?php echo e(route('app.admin.surat-keterangan-pindah-datang.district')); ?>', $(this)
                    .val(),
                    'kecamatan_tujuan');
            })
            $('#kecamatan_tujuan').on('change', function() {
                onChangeSelect('<?php echo e(route('app.admin.surat-keterangan-pindah-datang.village')); ?>', $(this)
                    .val(),
                    'desa_tujuan');
            });
            // $('#provinsi_asal').on('change', function() {
            //     onChangeSelect('<?php echo e(route('app.admin.surat-keterangan-pindah-datang.regency')); ?>', $(this)
            //         .val(),
            //         'kabupaten_asal');
            // });
            // $('#kabupaten_asal').on('change', function() {
            //     onChangeSelect('<?php echo e(route('app.admin.surat-keterangan-pindah-datang.district')); ?>', $(this)
            //         .val(),
            //         'kecamatan_asal');
            // })
            // $('#kecamatan_asal').on('change', function() {
            //     onChangeSelect('<?php echo e(route('app.admin.surat-keterangan-pindah-datang.village')); ?>', $(this)
            //         .val(),
            //         'desa_asal');
            // });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.mainSurat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/admin/layanan_umum/sk_pindah_datang/create.blade.php ENDPATH**/ ?>