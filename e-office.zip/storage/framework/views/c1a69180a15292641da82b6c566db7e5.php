<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Favicon icon-->
    

    <link rel="icon" type="image/png" sizes="16x16"
        href="<?php echo e(asset('landings/assets/images/logo/logo_kuningan.png')); ?>" />
    <link rel="icon" type="image/png" sizes="32x32"
        href="<?php echo e(asset('landings/assets/images/logo/logo_kuningan.png')); ?>" />
    <meta name="msapplication-TileColor" content="#8b3dff" />
    <meta name="msapplication-config" content="<?php echo e(asset('landings/assets/images/logo/logo_kuningan.png')); ?>" />

    <!-- Color modes -->
    <script src="<?php echo e(asset('landings/assets/js/vendors/color-modes.js')); ?>"></script>

    <!-- Libs CSS -->
    <link href="<?php echo e(asset('landings/assets/libs/simplebar/dist/simplebar.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('landings/assets/libs/bootstrap-icons/font/bootstrap-icons.min.css')); ?>" rel="stylesheet" />
    <!-- Option 1: Include in HTML -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">

    <!-- Scroll Cue -->
    <link rel="stylesheet" href="<?php echo e(asset('landings/assets/libs/scrollcue/scrollCue.css')); ?>" />
    

    <!-- Box icons -->
    <link rel="stylesheet" href="<?php echo e(asset('landings/assets/fonts/css/boxicons.min.css')); ?>" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('landings/assets/css/theme.min.css')); ?>" />
    <!-- Analytics Code -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-M8S4MT3EYG"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag("js", new Date());

        gtag("config", "G-M8S4MT3EYG");
    </script>

    <title>Website Desa | Go Digitals</title>
</head>
<?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/landing-page/layout/partials/head.blade.php ENDPATH**/ ?>