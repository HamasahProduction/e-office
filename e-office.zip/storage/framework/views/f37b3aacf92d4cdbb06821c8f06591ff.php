<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="sm"
    data-sidebar-image="none" data-layout-mode="blue" data-layout-width="fluid" data-layout-position="fixed"
    data-layout-style="default">
<head>


    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta name="robots" content="noindex, nofollow">
        <title><?php echo $__env->yieldContent('title', env('APP_NAME')); ?></title>
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::asset('logo/logo_kuningan.png')); ?>">
        <?php echo $__env->make('layout.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>

<body>
    <!-- Main Wrapper -->
    <div class="main-wrapper">
        <?php echo $__env->make('layout.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.partials.surat_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <div class="content container-fluid">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <?php echo $__env->yieldPushContent('after-body'); ?>
    <!-- /Main Wrapper -->
    <?php echo $__env->make('layout.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/layout/mainSurat.blade.php ENDPATH**/ ?>