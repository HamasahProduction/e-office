<?php $__env->startSection('title'); ?>
    Artikel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="py-2 ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="text-center">
                        <h1 class="mb-3">Daftar Artkel</h1>
                        <p class="mb-0">berikut adalah daftar artikel terbaru yang bisa di baca</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="mb-xl-9 py-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <?php if($article->count() > 0): ?>
                        <?php if(isset($article)): ?>
                            <div class="row gy-lg-7 gy-5">
                                <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <article class="col-lg-6 col-md-6 col-12">
                                        <figure class="mb-4 zoom-img">
                                            <a
                                                href="<?php echo e(route('lp.landing-page.artikel.artikel', ['category' => str_replace(' ', '-', $item->kategori->nama), 'slug' => $item->slug])); ?>">
                                                <img src="<?php echo e(asset($item->thumbnail == null ? 'assets/img/placeholder.jpg' : 'storage/' . $item->thumbnail)); ?>"
                                                    alt="blog" class="img-fluid rounded-3" />
                                            </a>
                                        </figure>

                                        <a href="#!"
                                            class="badge bg-primary-subtle text-primary-emphasis text-uppercase"><?php echo e($item->kategori->nama); ?></a>
                                        <h3 class="my-3 lh-base h4">
                                            <a href="<?php echo e(route('lp.landing-page.artikel.artikel', ['category' => str_replace(' ', '-', $item->kategori->nama), 'slug' => $item->slug])); ?>"
                                                class="text-reset"><?php echo e($item->judul); ?></a>
                                        </h3>
                                        <div class="d-flex align-items-center justify-content-between mb-3 mb-md-0">
                                            <div class="d-flex align-items-center">
                                                <div class="ms-2">
                                                    <a href="#" class="text-reset fs-6"><?php echo e($item->user); ?></a>
                                                </div>
                                            </div>
                                            <div class="ms-3"><span class="fs-6">
                                                    <?php echo e(Carbon\Carbon::parse($item->tgl_posting)->isoFormat('dddd, D MMMM Y')); ?></span>
                                            </div>
                                        </div>
                                    </article>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-12">
                                    <div class="mt-xl-7 mt-3">
                                        <a class="btn btn-outline-primary" href="#!">
                                            <span class="ms-2">Lihat Lainnya</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                            <figure class="mb-lg-9 mb-md-7 mb-5">
                                <img src="<?php echo e(asset('assets/img/placeholder.jpg')); ?>" alt="portfolio"
                                    class="img-fluid rounded-3">
                            </figure>
                        </div>
                    <?php endif; ?>
                </div>
                <aside class="col-lg-4">
                    <div class="offcanvas-lg offcanvas-end" id="blog-sidebar" tabindex="-1" aria-labelledby="blog-sidebar"
                        style="max-width: 340px">
                        <div class="offcanvas-header">
                            <h5 class="offcanvas-title h4" id="blog-sidebar">Sidebar</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                data-bs-target="#blog-sidebar"></button>
                        </div>
                        <div class="offcanvas-body flex-column">
                            <div class="mb-4">
                                <form>
                                    <label for="formGroupExampleInput" class="form-label visually-hidden">Example
                                        label</label>
                                    <input type="search" class="form-control" id="formGroupExampleInput"
                                        placeholder="Search Blog" />
                                </form>
                            </div>

                            <div class="card mb-4">
                                <div class="card-body">
                                    <h5 class="mb-4">Kategori</h5>
                                    <ul class="list-unstyled mb-0">
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="mb-2">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="7" height="7"
                                                    fill="currentColor" class="bi bi-circle-fill" viewBox="0 0 16 16">
                                                    <circle cx="8" cy="8" r="8" />
                                                </svg>
                                                <a href="<?php echo e(route('lp.landing-page.artikel.kategori',['slug'=>$category->slug])); ?>" class="text-reset ms-2 fw-medium">
                                                    <?php echo e($category->nama); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                            

                            <div class="card">
                                <div class="card-body">
                                    <h5 class="mb-4">Tags</h5>
                                    <a href="#!" class="btn btn-outline-primary btn-sm me-2 mb-2">block</a>
                                    <a href="#!" class="btn btn-outline-primary btn-sm me-2 mb-2">bootstrap5</a>
                                    <a href="#!" class="btn btn-outline-primary btn-sm me-2 mb-2">ui design</a>
                                    <a href="#!" class="btn btn-outline-primary btn-sm me-2 mb-2">bootstrap
                                        template</a>
                                    <a href="#!" class="btn btn-outline-primary btn-sm me-2 mb-2">web design</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing-page.layout.main_blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HADID\Documents\GIT\e-office\resources\views/landing-page/artikel/list_artikel.blade.php ENDPATH**/ ?>